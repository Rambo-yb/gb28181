(For the original README file, see [README2.md](README2.md))

End of development
==================

I find that this is a difficult decision, and I can't really think of a way
to present all the thoughts that have convinced me that this is a step I
need to make. This library started as my first real open source project way
back in 1999, when I was still very much a student, and it was the first time
I actually shared any kind of code with the outside world. Needless to say, 
it will always be linked to many good memories, and as such is hard to let 
go.

Times change however, and I feel I haven't been able to give this project the
attention it deserves for quite some time now, even though it probably does 
not really require that many interventions. As other things have come along 
that captured my interest, and as some health issues have come along that 
further captured some time, I think the time has come to make this difficult
decision.

So it is with mixed emotions, both sadness as well as a feeling of relief,
that I say goodbye to JRTPLIB.

Jori
