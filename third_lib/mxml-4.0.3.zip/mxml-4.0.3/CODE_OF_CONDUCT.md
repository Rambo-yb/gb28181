Code of Conduct
===============

My goal is to provide quality open source software that everyone can use.
While I may not be able to address every request or accept every contribution
to this project, I will do my best to develop and maintain it for the common
good.  As part of the open source community, I expect everyone to:

- Be friendly and patient.
- Be respectful, even if we disagree.
- Be honest.
- Be accepting of all people.
- Fully explain your concerns, issues, or ideas.
